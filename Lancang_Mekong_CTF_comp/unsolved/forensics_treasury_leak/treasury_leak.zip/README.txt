Investigate the seized workstation artifacts to find where the unauthorized escrow funds were sent.

Evidence files:
- email.msg
- ledger.xlsm
- shortcut.lnk

Flag Format: LMC{...}
